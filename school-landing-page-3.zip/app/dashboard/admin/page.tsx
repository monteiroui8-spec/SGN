"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { useAuth } from "@/lib/auth-context"
import { DashboardSidebar } from "@/components/dashboard/sidebar"
import { DashboardHeader } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { getNotasPendentes, type NotaPendente } from "@/lib/api"
import { Shield, Clock, CheckCircle2, XCircle, Loader2 } from "lucide-react"
import Link from "next/link"

export default function AdminDashboard() {
  const router = useRouter()
  const { user, isAuthenticated } = useAuth()
  const [notas, setNotas] = useState<NotaPendente[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!isAuthenticated || user?.type !== "admin") {
      router.push("/")
    }
  }, [isAuthenticated, user, router])

  useEffect(() => {
    getNotasPendentes()
      .then((res) => setNotas(res.data || []))
      .finally(() => setLoading(false))
  }, [])

  if (!isAuthenticated || user?.type !== "admin") return null

  const pendentes  = notas.filter((n) => n.estado === "Pendente")
  const aprovadas  = notas.filter((n) => n.estado === "Aprovado")
  const rejeitadas = notas.filter((n) => n.estado === "Rejeitado")

  return (
    <div className="min-h-screen bg-background">
      <DashboardSidebar />
      <div className="ml-64">
        <DashboardHeader />
        <main className="p-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <Shield className="w-7 h-7 text-primary" />
                Painel Administrativo
              </h2>
              <p className="text-muted-foreground">Gerencie e valide as notas do sistema</p>
            </div>

            {loading ? (
              <div className="flex items-center justify-center h-48">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : (
              <>
                {/* Stats */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card className="bg-warning/5 border-warning/20">
                    <CardContent className="p-4 flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-warning/20 flex items-center justify-center">
                        <Clock className="w-6 h-6 text-warning" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Pendentes</p>
                        <p className="text-3xl font-bold text-warning">{pendentes.length}</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card className="bg-success/5 border-success/20">
                    <CardContent className="p-4 flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-success/20 flex items-center justify-center">
                        <CheckCircle2 className="w-6 h-6 text-success" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Aprovadas</p>
                        <p className="text-3xl font-bold text-success">{aprovadas.length}</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card className="bg-destructive/5 border-destructive/20">
                    <CardContent className="p-4 flex items-center gap-3">
                      <div className="w-12 h-12 rounded-xl bg-destructive/20 flex items-center justify-center">
                        <XCircle className="w-6 h-6 text-destructive" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Rejeitadas</p>
                        <p className="text-3xl font-bold text-destructive">{rejeitadas.length}</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Pendentes recentes */}
                {pendentes.length > 0 && (
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between">
                      <CardTitle className="text-lg">Notas Pendentes de Validação</CardTitle>
                      <Link href="/dashboard/admin/validacao-notas">
                        <Button size="sm">Ver todas</Button>
                      </Link>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        {pendentes.slice(0, 5).map((n) => (
                          <div key={n.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                            <div>
                              <p className="font-medium">{n.aluno_nome}</p>
                              <p className="text-xs text-muted-foreground">
                                {n.disciplina_nome} · {n.turma_nome} · {n.trimestre_nome}
                              </p>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm text-muted-foreground">{n.professor_nome}</span>
                              <Badge className="bg-warning/20 text-warning border-0">
                                <Clock className="w-3 h-3 mr-1" />Pendente
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}

                {pendentes.length === 0 && (
                  <Card className="py-12">
                    <CardContent className="text-center">
                      <CheckCircle2 className="w-16 h-16 mx-auto text-success/50 mb-4" />
                      <h3 className="text-lg font-medium mb-2">Tudo em dia!</h3>
                      <p className="text-muted-foreground">Não há notas pendentes de validação.</p>
                    </CardContent>
                  </Card>
                )}
              </>
            )}
          </motion.div>
        </main>
      </div>
    </div>
  )
}
