"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { useAuth } from "@/lib/auth-context"
import { DashboardSidebar } from "@/components/dashboard/sidebar"
import { DashboardHeader } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { getTurmasProfessor, type TurmaProfessor } from "@/lib/api"
import { ClipboardList, Users, BookOpen, Send, Loader2 } from "lucide-react"
import Link from "next/link"

export default function ProfessorDashboard() {
  const router = useRouter()
  const { user, isAuthenticated } = useAuth()
  const [turmas, setTurmas] = useState<TurmaProfessor[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!isAuthenticated || user?.type !== "professor") {
      router.push("/login/professor")
    }
  }, [isAuthenticated, user, router])

  useEffect(() => {
    if (!user?.id) return
    getTurmasProfessor(user.id)
      .then((res) => setTurmas(res.data || []))
      .finally(() => setLoading(false))
  }, [user?.id])

  if (!isAuthenticated || user?.type !== "professor") return null

  const totalAlunos = turmas.reduce((s, t) => s + Number(t.total_alunos), 0)

  return (
    <div className="min-h-screen bg-background">
      <DashboardSidebar />
      <div className="ml-64">
        <DashboardHeader />
        <main className="p-6">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold">Bem-vindo, {user.nome.split(" ")[0]}!</h2>
              <p className="text-muted-foreground">Gerencie as suas turmas e notas</p>
            </div>

            {loading ? (
              <div className="flex items-center justify-center h-48">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : (
              <>
                {/* Stats */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="p-4 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                        <BookOpen className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Turmas</p>
                        <p className="text-2xl font-bold">{turmas.length}</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-success/10 flex items-center justify-center">
                        <Users className="w-5 h-5 text-success" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Total Alunos</p>
                        <p className="text-2xl font-bold">{totalAlunos}</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center">
                          <ClipboardList className="w-5 h-5 text-accent" />
                        </div>
                        <p className="text-sm text-muted-foreground">Lançar Notas</p>
                      </div>
                      <Link href="/dashboard/professor/notas">
                        <Button size="sm" className="gap-2">
                          <Send className="w-4 h-4" />Ir
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                </div>

                {/* Lista de turmas */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">As Minhas Turmas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {turmas.length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">
                        <Users className="w-12 h-12 mx-auto mb-3 opacity-40" />
                        <p>Sem turmas atribuídas. Contacte o administrador.</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {turmas.map((t) => (
                          <div key={`${t.turma_id}-${t.disciplina_id}`} className="flex items-center justify-between p-3 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors">
                            <div>
                              <p className="font-medium">{t.turma_nome}</p>
                              <p className="text-xs text-muted-foreground">{t.disciplina_nome} · {t.total_alunos} alunos</p>
                            </div>
                            <Link href="/dashboard/professor/notas">
                              <Button variant="outline" size="sm">Lançar Notas</Button>
                            </Link>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </>
            )}
          </motion.div>
        </main>
      </div>
    </div>
  )
}
